#include "Arduino.h"
#include "DFBLE.h"
void DFBLEClass::init(void)
{
	return;
}

void DFBLEClass::press_key(uint8_t key_value)
{
	Serial.print("AT+KEY=");Serial.print(key_value,DEC);Serial.println();
}
void DFBLEClass::press_key(uint8_t key_value1,uint8_t key_value2)
{
	Serial.print("AT+KEY=");Serial.print(key_value1,DEC);Serial.print("+");Serial.print(key_value2,DEC);Serial.println();
}
void DFBLEClass::press_key(uint8_t key_value1,uint8_t key_value2,uint8_t key_value3)
{
	Serial.print("AT+KEY=");Serial.print(key_value1,DEC);Serial.print("+");Serial.print(key_value2,DEC);Serial.print("+");Serial.print(key_value3,DEC);Serial.println();
}
DFBLEClass BLE;